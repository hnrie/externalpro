#include <iostream>
#include <Windows.h>
#include <Psapi.h>
#include <thread>

#include "src/instance/instance.hpp"
#include "src/instance/randomshit.hpp"
#include "src/memory/memory.hpp"
#include "src/structures/structures.hpp"

#include "src/globals.hpp"
#include "src/offsets.hpp"

#include "src/overlay/overlay.hpp"

struct dm
{
    instance datamodel;
    instance players;
    instance workspace;
};

void find_roblox()
{
    globals::rbx = FindWindowA(0, "Roblox");
    GetWindowThreadProcessId(globals::rbx, &globals::pid);
    globals::handle = OpenProcess(PROCESS_ALL_ACCESS, false, globals::pid);

    HMODULE modules[1024];
    DWORD real;

    if (EnumProcessModules(globals::handle, modules, sizeof(modules), &real))
        globals::base = (uintptr_t)(modules[0]);
}

dm get_datamodel()
{
    instance datamodel(memory::read<uintptr_t>(memory::read_module<uintptr_t>(offsets::fake_datamodel) + offsets::real_datamodel));
    instance players = datamodel.find_first_child("Players");
    instance workspace = datamodel.find_first_child("Workspace");

    return dm{ datamodel, players, workspace };
}

int main()
{
    find_roblox();

    std::thread(&overlay_manager::initialize_overlay, overlay_instance.get()).detach();

    dm shit = get_datamodel();
    auto datamodel = shit.datamodel;
    auto players = shit.players;
    auto workspace = shit.workspace;

    while (true)
    {
        globals::player_list.clear();

        auto local_char = workspace.find_first_child(instance(memory::read<uintptr_t>(players.address + offsets::local_player)).name());
        if (!local_char.address)
            continue;

        auto local_humanoid = local_char.find_first_child("Humanoid");
        if (!local_humanoid.address)
            continue;

        std::vector<instance> characters = random_shit::get_characters(workspace);
        for (const auto& character : characters)
        {
            auto player_instance = players.find_first_child(character.name());
            if (!player_instance.address)
                continue;

            auto hrp = character.find_first_child("HumanoidRootPart");
            if (!hrp.address)
                continue;

            auto humanoid = character.find_first_child("Humanoid");
            if (!humanoid.address)
                continue;

            std::string display_name = "";

            if (player_instance.display_name() != player_instance.name() || !player_instance.display_name().empty())
                display_name = player_instance.display_name();

            globals::player_list.push_back({ character.name(), display_name, hrp.position() });
        }

        memory::write<float>(local_humanoid.address + offsets::walk_speed, globals::walk_speed);
        memory::write<float>(local_humanoid.address + offsets::walk_speed_check, globals::walk_speed);
        memory::write<float>(local_humanoid.address + offsets::jump_power, globals::jump_power);
        memory::write<int>(local_humanoid.address + offsets::sitting, globals::sitting ? 0 : 257);
    }

    while (true) {};
}