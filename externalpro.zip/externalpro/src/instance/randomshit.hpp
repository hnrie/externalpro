#pragma once
#include "instance.hpp"
#include <vector>

namespace random_shit
{
    inline std::vector<instance> get_characters(instance workspace)
    {
        std::vector<instance> characters = {};
        std::vector<instance> children = workspace.children();

        for (const instance& child : children)
        {
            if (child.find_first_child("HumanoidRootPart").address != 0)
            {
                characters.push_back(child);
            }
        }

        return characters;
    }
}