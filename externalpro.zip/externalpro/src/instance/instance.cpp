#include "instance.hpp"

instance::instance(uintptr_t address) : address(address) {}

std::string instance::name() const {
    const auto ptr = memory::read<uintptr_t>(address + offsets::name);

    if (memory::decode_string(ptr).empty())
        return memory::read_string(ptr);
    else
        return memory::decode_string(ptr);
}

std::string instance::display_name() const {
    const auto ptr = memory::read<uintptr_t>(address + offsets::display_name);

    if (memory::decode_string(ptr).empty())
        return memory::read_string(ptr);
    else
        return memory::decode_string(ptr);
}

instance instance::parent() const {
    return instance(memory::read<uintptr_t>(address + offsets::parent));
}

std::vector<instance> instance::children() const {
    std::vector<instance> container;

    auto start = memory::read<uint64_t>(address + offsets::children);
    auto end = memory::read<uint64_t>(start + 0x8);

    for (auto child = memory::read<uint64_t>(start); child != end; child += 0x10)
        container.emplace_back(memory::read<uint64_t>(child));

    return container;
}

instance instance::find_first_child(const std::string& childname) const {
    for (const instance& child : children()) {
        if (child.name() == childname || memory::decode_string(memory::read<uintptr_t>(child.address + offsets::name)) == childname) {
            return child;
        }
    }
    return instance(0);
}

instance instance::find_first_descendant(const std::string& target_name) const {
    for (const auto& child : children()) {
        if (child.name() == target_name || memory::decode_string(memory::read<uintptr_t>(child.address + offsets::name)) == target_name)
            return child;

        const instance nested = child.find_first_descendant(target_name);
        if (nested.address)
            return nested;
    }
    return instance(0);
}

uintptr_t instance::primitive() const {
    return memory::read<uintptr_t>(address + offsets::primitive);
}

Vector3 instance::position() const {
    return memory::read<Vector3>(primitive() + offsets::position);
}