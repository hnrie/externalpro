#pragma once

#include <Windows.h>
#include <iostream>
#include <vector>

#include "structures/structures.hpp"

struct player_info {
    std::string name;
    std::string display_name;
    Vector3 position;
};

namespace globals
{
	inline DWORD pid;
    inline HANDLE handle;
    inline HWND rbx;
    inline uintptr_t base;

    inline float walk_speed = 16.0f;
    inline float jump_power = 50.0f;
    inline bool sitting = false;

    inline std::vector<player_info> player_list;
    inline bool updated = false;
}